package com.policy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "policyinformation")
public class PolicyInformation {
	
		@Id
		@GeneratedValue
		@Column( name = "id")
		private Integer id;
		
		@Column( name = "policyid")
		private String policyId;
		
		public String getEffectiveDate() {
			return effectiveDate;
		}

		public void setEffectiveDate(String effectiveDate) {
			this.effectiveDate = effectiveDate;
		}

		@Column( name = "firstname")
		private String firstName;
		
		@Column( name = "secondname")
		private String secondName;
		
		@Column( name = "effectivedate")
		private String effectiveDate;
		
		@Column( name = "requesteddate")
		private String requestedDate;
		
		@Column( name = "premium")
		private Double premium;
		
		@Column( name  = "totalpremium")
		private Double totalPremium;

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getPolicyId() {
			return policyId;
		}

		public void setPolicyId(String policyId) {
			this.policyId = policyId;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getSecondName() {
			return secondName;
		}

		public void setSecondName(String secondName) {
			this.secondName = secondName;
		}

		public String getRequestedDate() {
			return requestedDate;
		}

		public void setRequestedDate(String requestedDate) {
			this.requestedDate = requestedDate;
		}

		public Double getPremium() {
			return premium;
		}

		public void setPremium(Double premium) {
			this.premium = premium;
		}

		public Double getTotalPremium() {
			return totalPremium;
		}

		public void setTotalPremium(Double totalPremium) {
			this.totalPremium = totalPremium;
		}

		
		
		
}
