package com.policy.controller;

import org.springframework.web.bind.annotation.RestController;

import com.policy.entity.PolicyInformation;
import com.policy.request.ModifyPolicy;
import com.policy.response.AddPolicyResponse;
import com.policy.response.ModifyPolicyResponse;
import com.policy.service.PolicyManagementService;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/v1")
public class PolicyController{
	
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@Autowired
	private PolicyManagementService policyService;
	
	/*
	 * Method used to get policy details based on policy id and requested date
	 */
	
	@GetMapping(value = "/getPolicy")
	public ResponseEntity<List<PolicyInformation>> getPolicy(@RequestParam("policyId") String policyId,
			@RequestParam("requestDate") String requestDate) {

		logger.debug("Getting Rpp Account details before updating the details for accountnumber : {} and contract : {}", policyId, requestDate);

		List<PolicyInformation> policyInfo = policyService.getPolicy(policyId, requestDate);
		return ResponseEntity.ok(policyInfo);
	}
	
	/*
	 * Method used to add policy
	 */
	@PostMapping(value = "/addPolicy")
	public ResponseEntity<AddPolicyResponse> addPolicy(@RequestBody List<PolicyInformation> addPolicy) {
		logger.debug("Getting details to add new policy - ", addPolicy);
		AddPolicyResponse addPolicyResponse = policyService.addPolicy(addPolicy);
		return ResponseEntity.ok(addPolicyResponse);
	}
	/*
	 * Method used to update policy
	 */
		@PutMapping(value = "/modifyPolicy")
		public ResponseEntity<ModifyPolicyResponse> modifyPolicy(@RequestBody List<PolicyInformation> modifyPolicy) {
			logger.debug("Request to update policy, request are  {}", modifyPolicy);
			return ResponseEntity.ok(policyService.modifyPolicy(modifyPolicy));	
		}
		
		
	
}