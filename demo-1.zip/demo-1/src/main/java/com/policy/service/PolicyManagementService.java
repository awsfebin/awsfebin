package com.policy.service;

import java.util.List;

import com.policy.entity.PolicyInformation;
import com.policy.request.AddPolicy;
import com.policy.request.ModifyPolicy;
import com.policy.response.AddPolicyResponse;
import com.policy.response.ModifyPolicyResponse;

public interface PolicyManagementService {

	List<PolicyInformation> getPolicy(String policyId,String requestDate);
	AddPolicyResponse addPolicy(List<PolicyInformation> addPolicy);
	ModifyPolicyResponse modifyPolicy(List<PolicyInformation> modifyPolicy);
	
}
