package com.policy.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policy.entity.PolicyInformation;
import com.policy.repository.PolicyRepo;
import com.policy.request.ModifyPolicy;
import com.policy.response.AddPolicyResponse;
import com.policy.response.ModifyPolicyResponse;
import com.policy.service.PolicyManagementService;

@Service
public class PolicyManagementServiceImpl implements PolicyManagementService{

	@Autowired
	PolicyRepo policyRepo;
	
	@Override
	public List<PolicyInformation> getPolicy(String policyId, String requestDate) {
		double lPremium = 0.0;
		List<PolicyInformation> policyInfo = new ArrayList();
		PolicyInformation policyInfoRes = new PolicyInformation();
		List<PolicyInformation> insuredPersons = new ArrayList();
		
		
		policyInfo = policyRepo.findBypolicyIdAndRequestedDate(policyId,requestDate);
		for (PolicyInformation policyList : policyInfo) {
			policyInfoRes.setPolicyId(policyList.getPolicyId());
			policyInfoRes.setRequestedDate(policyList.getRequestedDate());
			policyInfoRes.setId(policyList.getId());
			policyInfoRes.setEffectiveDate(policyList.getEffectiveDate());
			policyInfoRes.setFirstName(policyList.getFirstName());
			policyInfoRes.setSecondName(policyList.getSecondName());
			lPremium = lPremium + policyList.getPremium();
			//policyInfoRes.setTotalPremium(lPremium);
			insuredPersons.add(policyInfoRes);
			
		}
		policyInfoRes.setTotalPremium(lPremium);
		return insuredPersons;
		
		
	}

	@Override
	public AddPolicyResponse addPolicy(List<PolicyInformation> addPolicy) {
		
		for(PolicyInformation addRequest : addPolicy) {
			
			if(!addPolicy.get(0).getEffectiveDate().equals("")) {
				if (isDateFuture(addPolicy.get(0).getEffectiveDate())) {
						addRequest.setEffectiveDate(addPolicy.get(0).getEffectiveDate());//setting start date
				}
			}
			if(!addPolicy.get(0).getFirstName().equals("")) {
				addRequest.setFirstName(addPolicy.get(0).getFirstName());
			}
			if(!addPolicy.get(0).getSecondName().equals("")) {
				addRequest.setSecondName(addPolicy.get(0).getSecondName());
			}
			if(addPolicy.get(0).getPremium() != 0.0) {
				addRequest.setPremium(addPolicy.get(0).getPremium());
			}
			
			policyRepo.save(addRequest);	
		}
		
		return null;
	}
	
	private boolean isDateFuture(String startDate) {
			LocalDate localDate = LocalDate.now(ZoneId.systemDefault());

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.mm.yyyy");
			LocalDate inputDate = LocalDate.parse(startDate, dtf);

			return inputDate.isAfter(localDate);
		}
		
		

	@Override
	public ModifyPolicyResponse modifyPolicy(List<PolicyInformation> modifyPolicy) {
		// TODO Auto-generated method stub
		
		ModifyPolicyResponse response = new ModifyPolicyResponse();
		for(PolicyInformation modifyRequest : modifyPolicy) {
			if (isDateFuture(modifyPolicy.get(0).getEffectiveDate())) {
				Optional<PolicyInformation> policy = policyRepo.findAllByPolicyId(modifyPolicy.get(0).getPolicyId());
				if(policy.isPresent()) {
					PolicyInformation curObj = policy.get();
					curObj.setEffectiveDate(modifyPolicy.get(0).getEffectiveDate());
					curObj.setFirstName(modifyPolicy.get(0).getFirstName());
					curObj.setSecondName(modifyPolicy.get(0).getSecondName());
					curObj.setPremium(modifyPolicy.get(0).getPremium());
					response.setEffectiveDate(curObj.getEffectiveDate());
					response.setFirstName(curObj.getFirstName());
					response.setSecondName(curObj.getSecondName());
					response.setPremium(curObj.getPremium());
				}
			}else {
				System.out.println("Effective date is not fucture date");
			}
			
		}
		return response;
	}

}
