package com.policy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.policy.entity.PolicyInformation;

@Repository
public interface PolicyRepo extends JpaRepository<PolicyInformation, Integer>{
	
	List<PolicyInformation> findBypolicyIdAndRequestedDate(String policyId,String requestDate);
	Optional<PolicyInformation> findAllByPolicyId(String policyId);

}
