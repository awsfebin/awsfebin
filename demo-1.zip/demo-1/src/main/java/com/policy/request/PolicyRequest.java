package com.policy.request;

import java.io.Serializable;

public class PolicyRequest implements Serializable{

	private static final long serialVersionUID = 4796490084312237060L;
	
	private String policyId;
	private String requestDate;
	
	public String getPolicyId() {
		return policyId;
	}
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	
	
	

}
