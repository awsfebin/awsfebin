package com.policy.request;

import java.io.Serializable;

public class AddPolicy implements Serializable{
	
	
	private static final long serialVersionUID = 6689961569332946477L;
	
	private String startDate;
	private String firstName;
	private String secondName;
	private Double premium;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getSecondName() {
		return secondName;
	}
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
	public Double getPremium() {
		return premium;
	}
	public void setPremium(Double premium) {
		this.premium = premium;
	}
	
	

}
